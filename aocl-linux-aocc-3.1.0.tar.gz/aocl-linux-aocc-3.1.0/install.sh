#!/bin/bash
# Set initial variables
CUSTOM_PATH=
SELECTED_LIBS=
MASTER_INSTALL=
LIBMAP=(blis libflame rng fftw securerng libm scalapack sparse) #dictionary for libraries
SELECTED_INT_TYPE=

error=0
rc=
ow=1 #overwrite
dir_name=
message=
lib=

#AMD Specific Variables
HOME_LOC=$HOME
AMD_LIBS_ROOT="$HOME/amd/aocl"
AMD_LIBS=(blis libflame rng fftw securerng libm scalapack sparse)
AMD_LIBS_LOG_FILE="amd-libs.log"
AMD_LIBS_CFG_FILE="amd-libs.cfg"
AMD_LIBS_REL="3.1.0"
AMD_LIBM_REL="3.1.0"
AMD_REL="3.1.0"

#storing output to log
rm -rf $AMD_LIBS_LOG_FILE #cleaning config and log file

help()
{
   # Display Help
   echo
   echo "Usage  : ./install.sh [-h] [-l <libname>] [-t <custom_dir_path>] [-i <lp64/ilp64 libraries>]"
   echo "Example: ./install.sh -l libm -t <custom_dir_path>"
   echo "options:"
   echo "-h     Print this Help."
   echo "-t     Custom target directory to install libraries"
   echo "-l 	Lib to be installed"
   echo "-i     Select LP64/ILP64 libs to be set as default"
   echo
}

# Quit nicely with messages as appropriate                                     #
################################################################################
quit()
{
   if [ $error != 0 ]
   then
      echo "Program terminated with error ID $error" 2>&1 | tee -a $AMD_LIBS_LOG_FILE
      rc=$error
   else
      if [ $error = 0 ]
      then
         echo "Program terminated normally" 2>&1 | tee -a $AMD_LIBS_LOG_FILE
         rc=0
      fi
   fi

   exit $rc
}

################################################################################
#  Install in custom directory                                                 #
################################################################################
# get the path from user
custom_dir()
{
    #read the user given path and check if its already exists or not
    if [[ ${CUSTOM_PATH:0:1} == "/" ]]; then
	#its an absolute path
        AMD_LIBS_ROOT=${CUSTOM_PATH}
    elif  [[ ${CUSTOM_PATH:0:2} == "./" ]]; then
	AMD_LIBS_ROOT=`pwd`
    else
	AMD_LIBS_ROOT=`pwd`/${CUSTOM_PATH}
    fi
}

################################################################################
#  Install specific libraries                                                  #
################################################################################
# get the list of libraries user wants to install
custom_libs()
{   
    AMD_LIBS=()
    #need to split the string of inputs given and install them
    LOWER_SELECTED_LIBS="$(echo ${SELECTED_LIBS[@]} | tr '[A-Z]' '[a-z]')"
    IFS=' '
    read -ra ADDR <<< "$LOWER_SELECTED_LIBS"
    for i in "${ADDR[@]}"; do # access each element of array
        lib_in=\\b$i\\b 
        if [[ ${LIBMAP[*]} =~ $lib_in  ]]; then
            AMD_LIBS+=($i)
        else
            echo "$i is not a library, Please use ./install.sh -h to know the usage" 2>&1 | tee -a $AMD_LIBS_LOG_FILE
            error=2
            quit $error
        fi
    done
}

################################################################################
# Process the input options                                                    #
################################################################################
# Get options
OPTSPEC="t:T:l:L:i:I:h:H"
while getopts "$OPTSPEC" options; do
   case "${options}" in
        [Hh]* )
            #print help
            help;
            exit;
        ;;
        [Tt]* ) # install libraries to specific directory
            CUSTOM_PATH="${OPTARG}";
            custom_dir;
        ;;
        [Ll]* )  # Selected libraries
            SELECTED_LIBS=("$OPTARG")
            until [[ $(eval "echo \${$OPTIND}") =~ ^-.* ]] || [ -z $(eval "echo \${$OPTIND}") ]; do
                SELECTED_LIBS+=($(eval "echo \${$OPTIND}"))
                OPTIND=$((OPTIND + 1))
            done
            custom_libs;
        ;;
        [Ii]* )
            SELECTED_INT_TYPE="${OPTARG}";
        ;;
        * ) # incorrect option
            echo "usage: ./install.sh [-h] [-l <libname>] [-t <custom_dir_path>] [-i <lp64/ilp64>]"  2>&1 | tee -a $AMD_LIBS_LOG_FILE
            exit ;;
   esac
done



################################################################################
# Gets simple (Y)es (N)o (Q)uit response from user. Loops until                #
# one of those responses is detected.                                          #
################################################################################
message_temp="WARNING!!! Do you wish to continue to overwrite the package --> "
ynq()
{
   # loop until we get a good answer and break out
   while true 
   do
      # Print the message
      echo -n "$message (yes | no | quit):"
      # Now get some input
      read input
      # Test the input
      if [ -z $input ]
      then
         # Invalid input - null
         echo "INPUT ERROR: Must be yes or no or quit in lowercase. Please try again." 2>&1 | tee -a $AMD_LIBS_LOG_FILE
      elif [ $input = "yes" ] || [ $input = "y" ]
      then
         ow=1
         break
      elif [ $input = "no" ] || [ $input = "n" ]
      then
         ow=0
         break
      elif [ $input = "Help" ] || [ $input = "h" ]
      then
         help
         break
      elif [ $input = "q" ] || [ $input = "quit" ]
      then
         quit
      else
         # Invalid input
         echo "INPUT ERROR: Must be y or n or q in lowercase. Please try again."  2>&1 | tee -a $AMD_LIBS_LOG_FILE
      fi
   done
}

##############################################################################
#  create directories and install libraries                                  #
##############################################################################
#implementaion of installtion

do_cmd()
{
    eval $1
    echo -e $1 >> $AMD_LIBS_CFG_FILE
}

init_env()
{
    libs_root="$AMD_LIBS_ROOT/$AMD_REL"
    libs_dir="$libs_root"
    libs_dir_lp64="$libs_dir/lib_LP64"
    libs_dir_ilp64="$libs_dir/lib_ILP64"

    include_dir_lp64="$libs_root/include_LP64";
    include_dir_ilp64="$libs_root/include_ILP64";

    #check if directories are avaible
    if [ ! -d "$libs_root" ]; then
        #create directories
        eval "mkdir -p $libs_root"
        if [[ $? -ne 0 ]]; then
            echo "Unable to create Directory $libs_root. Try with sudo " 2>&1 | tee -a $AMD_LIBS_LOG_FILE
            error=13
            quit $error 
        fi
    eval "mkdir -p $libs_dir"
        if [[ $? -ne 0 ]]; then
            echo "Unable to create Directory $libs_dir. Try with sudo " 2>&1 | tee -a $AMD_LIBS_LOG_FILE
            error=13
            quit $error 
        fi

    eval "mkdir -p $libs_dir_lp64"
        if [[ $? -ne 0 ]]; then
            echo "Unable to create Directory $libs_dir_lp64. Try with sudo " 2>&1 | tee -a $AMD_LIBS_LOG_FILE
            error=13
            quit $error
        fi

    eval "mkdir -p $libs_dir_ilp64"
        if [[ $? -ne 0 ]]; then
            echo "Unable to create Directory $libs_dir_ilp64. Try with sudo " 2>&1 | tee -a $AMD_LIBS_LOG_FILE
            error=13
            quit $error
        fi

    # check if include dirs (LP64, ILP64 exists)
    eval "mkdir $include_dir_lp64";
    if [[ $? -ne 0 ]]; then
        echo "Unable to create Directory $include_dir_lp64. Try with sudo " 2>&1 | tee -a $AMD_LIBS_LOG_FILE
        error 13
        quit $error
    fi

    eval "mkdir $include_dir_ilp64";
    if [[ $? -ne 0 ]]; then
        echo "Unable to create Directory $include_dir_ilp64. Try with sudo " 2>&1 | tee -a $AMD_LIBS_LOG_FILE
        error 13
        quit $error
    fi

	#check if the libs path is same or different
	if [[ -f $AMD_LIBS_CFG_FILE ]]; then
	    line1=$(head -n 1 $AMD_LIBS_CFG_FILE)
            if [[ $line1 != *"${libs_dir}"* ]]; then
	        echo "You have choosen different directory from previous installation, Only current target directory will be added to the config file"	
            fi
	fi 

        for lib in ${AMD_LIBS[@]}; do 
            untar_libs 
        done

    else
       #read input libs to be installed, ask user if he wants to overwrite
       #yes means, do overwrite 
       for lib in ${AMD_LIBS[@]}; do
           dir_name="$libs_root/amd-$lib"
           
	   if [ -d $dir_name ]; then
               message="$message_temp $lib ?"
               ynq
           fi

	   untar_libs 
           
       done
    fi

    if [[ -f $AMD_LIBS_CFG_FILE ]]; then
	  rm $AMD_LIBS_CFG_FILE
    fi

    #set env variables if libs dir is not empty
    if [ -d $libs_dir ]; then
        # this path will be by default exported
        do_cmd "export LD_LIBRARY_PATH=$libs_dir/lib:\$LD_LIBRARY_PATH"

        # set this variable to run examples
        do_cmd "export AOCL_ROOT=$libs_root;"

	    cp -r $AMD_LIBS_CFG_FILE $libs_root/$AMD_LIBS_CFG_FILE
    fi

}

untar_libs()
{
    pkg=""
    error=0

    #installations
    if [ "$lib" = "libm" ]; then
        pkg="aocl-libm-linux-aocc-$AMD_LIBM_REL.tar.gz"
    else
        pkg="aocl-$lib-linux-aocc-$AMD_LIBS_REL.tar.gz"
    fi

    if [[ ! -f $pkg ]];then
	    echo "Error: No package found for ${pkg}" 2>&1 | tee -a $AMD_LIBS_LOG_FILE
    fi

    if [[ -d $dir_name ]] && [[ "$ow" -eq 1 ]]; then
        echo -e Untarring $lib 2>&1 | tee -a $AMD_LIBS_LOG_FILE
        echo "writing the library: $lib" 2>&1 | tee -a $AMD_LIBS_LOG_FILE
        tar -xvzf ${pkg} -C $AMD_LIBS_ROOT/$AMD_REL 2>&1 | tee -a $AMD_LIBS_LOG_FILE
    elif [[ -d $dir_name ]] && [[ "$ow" -eq 0 ]]; then
        echo "Library already exists, not overwriting" 2>&1 | tee -a $AMD_LIBS_LOG_FILE
    else
        #directory will be created and links will setup
	echo -e Untarring $lib 2>&1 | tee -a $AMD_LIBS_LOG_FILE
        echo "writing the library: $lib" 2>&1 | tee -a $AMD_LIBS_LOG_FILE
        tar -xvzf ${pkg} -C $AMD_LIBS_ROOT/$AMD_REL 2>&1 | tee -a $AMD_LIBS_LOG_FILE
    fi

	    master_install
}

master_install ()
{
    libs_root="$AMD_LIBS_ROOT/$AMD_REL"
    libs_dir="$libs_root"
    # extra inc directories
    include_dir_lp64="$libs_root/include_LP64";
    include_dir_ilp64="$libs_root/include_ILP64";

    #check if lib and include directories present
    if [ -d $libs_dir ] && [ -d $include_dir_lp64 ] && [ -d $include_dir_ilp64 ]; then
        collect_input
        collect_lib
    fi
}

collect_input ()
{
    libs_root="$AMD_LIBS_ROOT/$AMD_REL"

    #return if lib are scalapack
    if [ "$lib" = "scalapack" ]; then
           return
    fi
    #copy all includes in include directory
    key=amd-$lib/include
    if [ "$lib" = "rng" ]; then
          key=amd-$lib/$lib/include
    fi

    for filepath in $libs_root/$key/*
    do
        filename=$(basename $filepath)
        if [ "$filename" = "*" ]; then
                echo  "WARNING: $key not found proceeding with next  library "
                return
        fi

        if [ "$lib" = "blis" ]; then
            cp -r $libs_root/$key/lp64/* $libs_root/include_LP64/;
            cp -r $libs_root/$key/ilp64/* $libs_root/include_ILP64/;
        fi

        #copy only if its a header file
        if [[ -f $libs_root/$key/$filename ]]; then
            cp $libs_root/$key/$filename $libs_root/include_LP64/$filename;
            cp $libs_root/$key/$filename $libs_root/include_ILP64/$filename;
        fi
    done

    rm -rf $libs_root/$key
    echo -e "collected includes  in the common include directory" 2>&1 | tee -a $AMD_LIBS_LOG_FILE
    echo  2>&1 | tee -a $AMD_LIBS_LOG_FILE
}



collect_lib()
{
    libs_root="$AMD_LIBS_ROOT/$AMD_REL"
    libs_dir="$libs_root"

    libs_dir_lp64="$libs_dir/lib_LP64"
    libs_dir_ilp64="$libs_dir/lib_ILP64"

    # collect all libraries at one place 
    key=amd-$lib/lib
    if [ "$lib" = "rng" ]; then
	  key=amd-$lib/$lib/lib
    fi
    for filepath in $libs_root/$key/*
    do
        filename=$(basename $filepath)
	    if [ "$filename" = "*" ]; then 
		    echo  "**********WARNING: $key not found proceeding with next  library********* "
		    return
	    fi

        if [ "$filename" = "lp64" ]; then
            cp -r $libs_root/$key/$filename/* $libs_dir_lp64/
        elif [ "$filename" = "ilp64" ]; then
            cp -r $libs_root/$key/$filename/* $libs_dir_ilp64/
        else
            #for non lp64, ilp64 variants (like fftw, libm)
            cp -r $libs_root/$key/$filename $libs_dir_ilp64/
            cp -r $libs_root/$key/$filename $libs_dir_lp64/
        fi
	    #cp -r $libs_root/$key/$filename $libs_dir/$filename/
    done
    rm -rf $libs_root/$key
    echo -e "collected libs for $lib in the common lib directory" 2>&1 | tee -a $AMD_LIBS_LOG_FILE
    echo  2>&1 | tee -a $AMD_LIBS_LOG_FILE
}

# format the messages
print_result() {
    install_path=$1
    libs_root=$2
    printf -- '-%.0s' {1..100};
    printf "\nAOCL INSTALLED SUCCESSFULLY AT: $install_path\n";
    printf -- '-%.0s' {1..100};
    printf "\nSteps to setup:\n";
    printf -- '-%.0s' {1..100};
    printf "\nSetup AOCL environment by executing the below command\n";
    printf "\tsource $libs_root/amd-libs.cfg\n";
    printf -- '-%.0s' {1..100};
    printf "\n";
}

# chose to create symlinks for lp64
create_symlinks_lp64() {
    lib_path=$1
    lib_path_lp64=${lib_path}/lib_LP64;

    # if folder isnt empty,
    if ! [ -z "$(ls -A ${lib_path_lp64})" ]; then
        cd $lib_path;

        if [ -L ./lib ]; then
            rm -rf ./lib;
        fi
        ln -s ./lib_LP64 ./lib;
        cd ../;
        print_result "$lib_path/lib" "$lib_path"
    fi
}

# chose to create symlinks for ilp64
create_symlinks_ilp64() {
    lib_path=$1
    lib_path_ilp64=${lib_path}/lib_ILP64;
    # if folder isnt empty,
    if ! [ -z "$(ls -A ${lib_path_ilp64})" ]; then
        cd $lib_path;

        if [ -L ./lib ]; then
            rm -rf ./lib;
        fi
        ln -s ./lib_ILP64 ./lib;
        cd ../;
        print_result "$lib_path/lib" "$lib_path"
    fi
}

# chose to create symlinks for include ilp64
create_symlinks_include_ilp64() {
    inc_path=$1
    inc_path_ilp64=${inc_path}/include_ILP64;
    # if folder isnt empty,
    if ! [ -z "$(ls -A ${inc_path_ilp64})" ]; then
        cd $inc_path;

        if [ -L ./include ]; then
            rm -rf ./include;
        fi
        ln -s ./include_ILP64/ ./include;

        cd ../;
    fi
}

# chose to create symlinks for include lp64
create_symlinks_include_lp64() {
    inc_path=$1
    inc_path_lp64=${inc_path}/include_LP64;
    # if folder isnt empty,

    if ! [ -z "$(ls -A ${inc_path_lp64})" ]; then
        cd $inc_path;

        if [ -L ./include ]; then
            rm -rf ./include;
        fi
        ln -s ./include_LP64/ ./include;

        cd ../;
    fi
}

# choose to install lp64/ilp64
install_special() {
    #ask if we need to install lp64, ilp64 symlinks
    lib_root=$1
    lib_path=${lib_root};

    while true; do
    printf -- '-%.0s' {1..125}
    printf "\nDo you want to set LP64 or ILP64 libraries as default libraries? (Enter 1 for LP64 / 2 for ILP64 / Default option: 1)\n"
    printf -- '-%.0s' {1..125}
    printf "\n"
    read -p "" opt
    case $opt in
        [1]* ) echo "Setting LP64 libs as default";  create_symlinks_lp64 ${lib_path}; create_symlinks_include_lp64 ${libs_root};  break;;
        [2]* ) echo "Setting ILP64 libs as default"; create_symlinks_ilp64 ${lib_path}; create_symlinks_include_ilp64 ${libs_root}; break;;
         * )    echo "Setting LP64 libs as default"; create_symlinks_lp64 ${lib_path}; create_symlinks_include_lp64 ${libs_root};break;;
    esac
    done
}

install() {
    init_env
    echo "AOCL available at: $libs_root" 2>&1 | tee -a $AMD_LIBS_LOG_FILE

    #here check the value of $SELECTED_INT_TYPE and accordingly set sym links
    if [ "$SELECTED_INT_TYPE" = "lp64" ]; then
        printf "Setting LP64 libs as default\n";
        create_symlinks_lp64 ${libs_root};
        create_symlinks_include_lp64 ${libs_root};

    elif [ "$SELECTED_INT_TYPE" = "ilp64" ]; then
        printf "Setting ILP64 libs as default\n";
        create_symlinks_ilp64 ${libs_root};
        create_symlinks_include_ilp64 ${libs_root};

    else
        install_special $libs_root; # call default option where user will be prompted to choose ilp64/lp64
    fi

    echo
}


install
