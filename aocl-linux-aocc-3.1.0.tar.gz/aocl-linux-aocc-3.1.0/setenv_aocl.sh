# Run this script as #
# bash setenv_aocl.sh <lp64 / ilp64>

opt=$1;

printf "Setting $opt as default...\n";

# if symlink exists, delete it, and..
if [ -L ./lib ]; then
    rm -rf ./lib;
    rm -rf ./include;
fi

# ... based on the option, create it
if [ "${opt}" = "lp64" ]; then
    ln -s ./lib_LP64 ./lib;
    ln -s ./include_LP64 ./include;
elif [ "${opt}" = "ilp64" ]; then
    ln -s ./lib_ILP64 ./lib;
    ln -s ./include_ILP64 ./include;
else
    ln -s ./lib_LP64 ./lib;
    ln -s ./include_LP64 ./include;
fi

printf "Setting $opt as default is completed\n";
